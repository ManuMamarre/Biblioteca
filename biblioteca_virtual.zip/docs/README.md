# Biblioteca Virtual

Proyecto en C++ con patrones de diseño