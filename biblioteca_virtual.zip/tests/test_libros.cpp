// test_libros.cpp
