// LibroController.hpp
