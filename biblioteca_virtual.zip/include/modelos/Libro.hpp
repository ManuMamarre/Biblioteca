// Libro.hpp
