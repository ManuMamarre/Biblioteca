// Ejemplar.hpp
