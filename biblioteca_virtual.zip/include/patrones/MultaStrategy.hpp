// MultaStrategy.hpp
