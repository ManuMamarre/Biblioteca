// LibroController.cpp
