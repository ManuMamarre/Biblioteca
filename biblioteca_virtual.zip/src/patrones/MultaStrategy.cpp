// MultaStrategy.cpp
