// Libro.cpp
