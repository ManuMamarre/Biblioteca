// Ejemplar.cpp
